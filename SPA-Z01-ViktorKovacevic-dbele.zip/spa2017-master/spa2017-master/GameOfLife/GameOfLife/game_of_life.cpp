#include "game_of_life.h"

bool game_of_life::slucajna_vrijednost()
{
	
	int a;
	a = rand() % 100 + 1;
	if (a <= 20) {
		return true;
	}
	else { return false; }
}

int game_of_life::broj_zivih_susjeda(int i, int j)
{   int brojac = 0;
	for (int x = -1; x < 2; x++) {
		for (int y = -1; y < 2; y++) {
			
			int a = 0;
			int b = 0;
			a = i + x;
			b = j + y;
			if ((a > -1 || a < 20) && (b > -1 || b < 40)) { if (_generacija[a][b] == '*') { brojac++; } }
		}
	}
	if (celija_ziva(i, j)) { return brojac - 1; }
	else { return brojac; }
}

bool game_of_life::celija_ziva(int i, int j)
{
	if (_generacija[i][j] == '*') {
		return true;
	}
	else { return false; }
}

game_of_life::game_of_life()
{
	srand(time(nullptr));
	for (int i = 0; i < REDAKA; i++) {
		for (int j = 0; j < STUPACA; j++) {
			if (slucajna_vrijednost()) {
				_generacija[i][j] = '*';
			}
			else { _generacija[i][j] = '-'; }
		}
	}
}

void game_of_life::sljedeca_generacija()
{
	for (int i = 0; i < REDAKA; i++) {
		for (int j = 0; j < STUPACA; j++) {
			int c = 0;
			c = broj_zivih_susjeda(i, j);
			if (celija_ziva(i, j)) {
				if (c < 2 || c>3) {
					_sljedeca_generacija[i][j] = '-';
				}
				else { _sljedeca_generacija[i][j] = '*'; }
			}
			else {
				if (c == 3) { _sljedeca_generacija[i][j] = '*'; }
				else { _sljedeca_generacija[i][j] = '-'; }
			}
			}
	}
	for (int i = 0; i < REDAKA; i++) {
		for (int j = 0; j < STUPACA; j++) {
			_generacija[i][j] = _sljedeca_generacija[i][j];
		}
}
}

void game_of_life::iscrtaj()
{
	system("cls");
	for (int i = 0; i < REDAKA; i++) {
		for (int j = 0; j < STUPACA; j++) {
			cout << _generacija[i][j];
		}
		cout << endl;
	}
}

